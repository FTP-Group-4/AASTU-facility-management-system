
  # PWA UI for Facilities Management

  This is a code bundle for PWA UI for Facilities Management. The original project is available at https://www.figma.com/design/wIQurFLguu39iUH4ZVvCKg/PWA-UI-for-Facilities-Management.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  